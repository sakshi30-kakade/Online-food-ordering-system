package com.foodify.service;

public class UserService {

}
