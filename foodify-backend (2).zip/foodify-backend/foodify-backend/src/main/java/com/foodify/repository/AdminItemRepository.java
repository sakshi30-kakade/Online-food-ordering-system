package com.foodify.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.foodify.model.AdminItem;

public interface AdminItemRepository extends JpaRepository<AdminItem, Long> {
    AdminItem findByUsernameAndPassword(String username, String password);
}
