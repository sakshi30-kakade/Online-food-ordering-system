package com.foodify.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String phone;
    private String address;
    private String payment_method;

    @Column(columnDefinition = "TEXT") // To store long JSON string
    private String items;

    private double price;
    private int quantity;
    private LocalDateTime date;

    // Default constructor
    public Order() {}

    // Parameterized constructor
    public Order(String name, String phone, String address, String items, double price, int quantity, LocalDateTime date, String payment_method) {
        this.name = name;
        this.phone = phone;
        this.address = address;
        this.items = items;
        this.price = price;
        this.quantity = quantity;
        this.date = date;
        this.payment_method = payment_method;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getItems() {
        return items;
    }

    public void setItems(String items) {
        this.items = items;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }
    public String getpayment_method() {
        return payment_method;
    }

    public void setpayment_method(String payment_method) {
        this.payment_method = payment_method;
    }
}
