//package com.foodify.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.security.config.Customizer;
//import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
//
//@Configuration
//public class SecurityConfig {
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//        http
//            .csrf(csrf -> csrf.disable()) // Disable CSRF for APIs
//            .authorizeHttpRequests(auth -> auth
//                .requestMatchers(new AntPathRequestMatcher("/api/**")).permitAll() // Explicit matcher
//                .anyRequest().authenticated()
//            )
//            .cors(Customizer.withDefaults()) // Enable default CORS (important)
//            .formLogin(form -> form.disable())
//            .httpBasic(httpBasic -> httpBasic.disable());
//
//        return http.build();
//    }
//}





//package com.foodify.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.Customizer;
//import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.web.servlet.config.annotation.CorsRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//
//@Configuration
//public class SecurityConfig {
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//        http
//            .csrf(csrf -> csrf.disable()) // Disable CSRF for APIs
//            .authorizeHttpRequests(auth -> auth
//                // Allow admin login without authentication
//                .requestMatchers(new AntPathRequestMatcher("/api/admin/login")).permitAll()
//                // Allow all other /api/** requests for now
////                .requestMatchers(new AntPathRequestMatcher("/api/**")).permitAll()
////                .anyRequest().authenticated()
////            )
////            .cors(Customizer.withDefaults()) // Enable default CORS
////            .formLogin(form -> form.disable())
////            .httpBasic(httpBasic -> httpBasic.disable());
////
////        return http.build();
//    }

    // CORS configuration so frontend can call backend
//    @Bean
//    public WebMvcConfigurer corsConfigurer() {
//        return new WebMvcConfigurer() {
//            @Override
//            public void addCorsMappings(CorsRegistry registry) {
//                registry.addMapping("/**")
//                        .allowedOrigins("http://localhost:3000") // React dev server
//                        .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
//                        .allowedHeaders("*")
//                        .allowCredentials(true);
//            }
//        };
//    }
//}








package com.foodify.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .cors(Customizer.withDefaults())
            .authorizeHttpRequests(auth -> auth
                // public admin login endpoint
                .requestMatchers(new AntPathRequestMatcher("/api/admin/login")).permitAll()
                // allow the rest of your APIs (you already check JWT manually in AdminController)
                .requestMatchers(new AntPathRequestMatcher("/api/**")).permitAll()
                // nothing else needs auth for now
                .anyRequest().permitAll()
            )
            .formLogin(form -> form.disable())
            .httpBasic(basic -> basic.disable());

        return http.build();
    }
}

