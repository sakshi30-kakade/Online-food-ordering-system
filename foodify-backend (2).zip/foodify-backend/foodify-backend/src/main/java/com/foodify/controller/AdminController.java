package com.foodify.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.foodify.model.AdminItem;
import com.foodify.repository.AdminItemRepository;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminController {

    @Autowired
    private AdminItemRepository adminRepository;

    @PostMapping("/login")
    public String login(@RequestBody AdminItem admin) {
        AdminItem found = adminRepository.findByUsernameAndPassword(admin.getUsername(), admin.getPassword());
        if (found != null) {
            return "SUCCESS";
        } else {
            return "FAIL";
        }
    }
}
