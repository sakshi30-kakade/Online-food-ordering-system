package com.foodify.repository;

import com.foodify.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    
    // ✅ Existing queries
    User findByEmail(String email);
    User findByUsername(String username);

    // ✅ Correct way (Spring Data JPA will auto-implement this)
    User findByUsernameAndPassword(String username, String password);
}
