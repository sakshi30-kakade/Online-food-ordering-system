//package com.foodify.controller;
//
//import com.foodify.model.User;
//import com.foodify.repository.UserRepository;
//import com.foodify.service.EmailService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.Map;
//import java.util.Random;
//
//@RestController
//@RequestMapping("/api/users")
//@CrossOrigin(origins = "http://localhost:3000")
//public class UserController {
//
//    @Autowired
//    private UserRepository userRepo;
//
//    @Autowired
//    private EmailService emailService;
//
//    // ✅ SIGNUP
//    @PostMapping("/signup")
//    public ResponseEntity<?> signup(@RequestBody User user) {
//        if (user.getUsername() == null || user.getEmail() == null || user.getPassword() == null) {
//            return ResponseEntity.badRequest().body("❌ All fields are required.");
//        }
//
//        if (userRepo.findByEmail(user.getEmail()) != null) {
//            return ResponseEntity.badRequest().body("❌ Email already registered!");
//        }
//
//        if (userRepo.findByUsername(user.getUsername()) != null) {
//            return ResponseEntity.badRequest().body("❌ Username already taken!");
//        }
//
//        userRepo.save(user);
//        return ResponseEntity.ok("🎉 Signup successful!");
//    }
//
//    // ✅ LOGIN
//    @PostMapping("/login")
//    public ResponseEntity<?> login(@RequestBody User loginData) {
//        if (loginData.getUsername() == null || loginData.getPassword() == null) {
//            return ResponseEntity.badRequest().body("❌ Username and password required.");
//        }
//
//        User user = userRepo.findByUsername(loginData.getUsername());
//        if (user == null) {
//            return ResponseEntity.badRequest().body("❌ User not found!");
//        }
//
//        if (!user.getPassword().equals(loginData.getPassword())) {
//            return ResponseEntity.badRequest().body("❌ Incorrect password!")
//        }
//
//        user.setPassword(null); // don’t return password
//        return ResponseEntity.ok(user);
//    }
//
//    // ✅ FORGOT PASSWORD - Send OTP using SendGrid
//    @PostMapping("/forgot-password")
//    public ResponseEntity<String> sendOtp(@RequestBody Map<String, String> payload) {
//        String email = payload.get("email");
//        User user = userRepo.findByEmail(email);
//
//        if (user == null) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("❌ Email not found.");
//        }
//
//        String otp = String.valueOf(new Random().nextInt(900000) + 100000);
//        user.setOtp(otp);
//        userRepo.save(user);
//
//        String result = emailService.sendOtpEmail(email, otp);
//        return ResponseEntity.ok(result);
//    }
//
//    // ✅ VERIFY OTP
//    @PostMapping("/verify-otp")
//    public ResponseEntity<String> verifyOtp(@RequestBody Map<String, String> payload) {
//        String email = payload.get("email");
//        String otp = payload.get("otp");
//
//        User user = userRepo.findByEmail(email);
//        if (user == null || !otp.equals(user.getOtp())) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("❌ Invalid OTP.");
//        }
//
//        return ResponseEntity.ok("✅ OTP verified. You may now reset your password.");
//    }
//
//    // ✅ RESET PASSWORD
//    @PostMapping("/reset-password")
//    public ResponseEntity<String> resetPassword(@RequestBody Map<String, String> payload) {
//        String email = payload.get("email");
//        String newPassword = payload.get("newPassword");
//
//        User user = userRepo.findByEmail(email);
//        if (user == null) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("❌ User not found.");
//        }
//
//        user.setPassword(newPassword);
//        user.setOtp(null);
//        userRepo.save(user);
//
//        return ResponseEntity.ok("✅ Password updated successfully.");
//    }
//}






package com.foodify.controller;

import com.foodify.model.User;
import com.foodify.repository.UserRepository;
import com.foodify.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Random;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private EmailService emailService;

    // ✅ SIGNUP
    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody User user) {
        if (user.getUsername() == null || user.getEmail() == null || user.getPassword() == null) {
            return ResponseEntity.badRequest().body("❌ All fields are required.");
        }

        if (userRepo.findByEmail(user.getEmail()) != null) {
            return ResponseEntity.badRequest().body("❌ Email already registered!");
        }

        if (userRepo.findByUsername(user.getUsername()) != null) {
            return ResponseEntity.badRequest().body("❌ Username already taken!");
        }

        userRepo.save(user);
        return ResponseEntity.ok("🎉 Signup successful!");
    }

    // ✅ LOGIN (Handles both Admin & User without breaking existing user login)
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginRequest) {
        if (loginRequest.getUsername() == null || loginRequest.getPassword() == null) {
            return ResponseEntity.badRequest().body("❌ Username and password required.");
        }

        // ✅ Admin login (hardcoded for now)
        if ("admin".equalsIgnoreCase(loginRequest.getUsername()) && 
            "admin123".equals(loginRequest.getPassword())) {
            return ResponseEntity.ok(Map.of(
                    "role", "admin",
                    "username", "admin"
            ));
        }

        // ✅ User login (check DB)
        User user = userRepo.findByUsernameAndPassword(
                loginRequest.getUsername(),
                loginRequest.getPassword()
        );

        if (user == null) {
            return ResponseEntity.status(401).body("❌ Invalid credentials");
        }

        // ✅ Don't send password in response
        user.setPassword(null);
        return ResponseEntity.ok(Map.of(
                "role", "user",
                "username", user.getUsername(),
                "email", user.getEmail()
        ));
    }

    // ✅ FORGOT PASSWORD - Send OTP using SendGrid
    @PostMapping("/forgot-password")
    public ResponseEntity<String> sendOtp(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        User user = userRepo.findByEmail(email);

        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("❌ Email not found.");
        }

        String otp = String.valueOf(new Random().nextInt(900000) + 100000);
        user.setOtp(otp);
        userRepo.save(user);

        String result = emailService.sendOtpEmail(email, otp);
        return ResponseEntity.ok(result);
    }

    // ✅ VERIFY OTP
    @PostMapping("/verify-otp")
    public ResponseEntity<String> verifyOtp(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        String otp = payload.get("otp");

        User user = userRepo.findByEmail(email);
        if (user == null || !otp.equals(user.getOtp())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("❌ Invalid OTP.");
        }

        return ResponseEntity.ok("✅ OTP verified. You may now reset your password.");
    }

    // ✅ RESET PASSWORD
    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        String newPassword = payload.get("newPassword");

        User user = userRepo.findByEmail(email);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("❌ User not found.");
        }

        user.setPassword(newPassword);
        user.setOtp(null);
        userRepo.save(user);

        return ResponseEntity.ok("✅ Password updated successfully.");
    }
}
