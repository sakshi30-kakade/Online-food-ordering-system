package com.foodify.service;

import com.sendgrid.*;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Value("${SENDGRID_API_KEY}")
    private String sendGridApiKey;

    public String sendOtpEmail(String toEmail, String otp) {
        Email from = new Email("sakshikakade30@gmail.com"); // ✅ verified sender
        String subject = "Your OTP Code for Password Reset";
        Email to = new Email(toEmail);
        Content content = new Content("text/plain", "Your OTP is: " + otp);
        Mail mail = new Mail(from, subject, to, content);

        SendGrid sg = new SendGrid(sendGridApiKey);
        Request request = new Request();

        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());

            Response response = sg.api(request);
            System.out.println("SendGrid Response: " + response.getStatusCode());

            return response.getStatusCode() == 202
                ? "✅ OTP sent to your email."
                : "❌ Failed to send OTP. Status: " + response.getStatusCode();

        } catch (Exception e) {
            e.printStackTrace();
            return "❌ Error sending OTP.";
        }
    }
}
