package com.foodify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodifyBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
